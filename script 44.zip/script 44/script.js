
let valueInput = document.querySelector("#valueId");
let btnValue = document.querySelector(".btnValue");
let listGroupElement = document.querySelector(".list-group");
let valuePriceInput = document.querySelector("#price");
let orderSelect = document.querySelector(".form-select");
let minInput = document.querySelector("#min");
let maxInput = document.querySelector("#max");

let lists = [
    { id: 1, label: "Apple", price: 1000 },
    { id: 2, label: "Mango", price: 3000 },
    { id: 3, label: "Kiwi", price: 1500 },
];

let myProduct = null;

let storage = localStorage.getItem("list");
if (storage) {
    lists = JSON.parse(storage);
}
lists.forEach(viewPrint);

btnValue.addEventListener("click", () => {
    if (myProduct) {
        update();
    } else {
        add();
    }
});

function add() {
    let newList = {
        id: Date.now(),
        label: valueInput.value.trim(),
        price: parseFloat(valuePriceInput.value),
    };

    if (!newList.label || isNaN(newList.price))
        return;

    lists.push(newList);
    localStorage.setItem("list", JSON.stringify(lists));
    viewPrint(newList);

    valueInput.value = "";
    valuePriceInput.value = "";
}

function update() {
    myProduct.label = valueInput.value.trim();
    myProduct.price = parseFloat(valuePriceInput.value);

    let dataSearch = document.querySelector(`[data-id="${myProduct.id}"]`);
    if (dataSearch) {
        dataSearch.innerHTML = myProduct.label;
    }
    let priceSpan = document.querySelector(`[data-update="${myProduct.id}"]`);
    if (priceSpan) {
        priceSpan.innerHTML = myProduct.price;
    }

    localStorage.setItem("list", JSON.stringify(lists));

    btnValue.innerHTML = "Add";
    valueInput.value = "";
    valuePriceInput.value = "";
    myProduct = null;
}

orderSelect.addEventListener("change", function (e) {
    let sortedLists = [...lists];

    if (e.target.value === "1") {
        sortedLists.sort((a, b) => a.price - b.price);
    } else if (e.target.value === "2") {
        sortedLists.sort((a, b) => b.price - a.price);
    }

    updateView(sortedLists);
});

let filterTimeout;
[minInput, maxInput].forEach(input => {
    input.addEventListener("input", function () {
        clearTimeout(filterTimeout);
        filterTimeout = setTimeout(applyPriceFilter, 1000);
    });
});

function applyPriceFilter() {
    let min = parseFloat(minInput.value) || 0;
    let max = parseFloat(maxInput.value) || Infinity;

    let filteredLists = lists.filter(item => item.price >= min && item.price <= max);
    updateView(filteredLists);
}

function viewPrint(list) {
    let newLiTag = document.createElement("li");
    newLiTag.setAttribute("class", "list-group-item list-group-item-action d-flex justify-content-between align-items-center");

    newLiTag.innerHTML = `<span class="item text" data-id="${list.id}">${list.label}</span>`;

    let priceSpan = document.createElement("span");
    priceSpan.classList.add("item", "text");
    priceSpan.dataset.update = list.id;
    priceSpan.textContent = list.price;
    newLiTag.appendChild(priceSpan);

    let sectionBtn = document.createElement("div");
    let newBtn = document.createElement("button");
    newBtn.setAttribute("class", "delete-me btn btn-danger btn-sm");
    newBtn.innerText = "Delete";
    sectionBtn.appendChild(newBtn);

    let newEditBtn = document.createElement("button");
    newEditBtn.setAttribute("class", "edit-me btn btn-warning btn-sm");
    newEditBtn.innerText = "Edit";
    sectionBtn.appendChild(newEditBtn);

    newLiTag.appendChild(sectionBtn);
    listGroupElement.appendChild(newLiTag);

    newBtn.onclick = function () {
        lists = lists.filter((res) => res.id !== list.id);
        localStorage.setItem("list", JSON.stringify(lists));
        newLiTag.remove();
    };

newEditBtn.onclick = function () {
        myProduct = lists.find((res) => res.id === list.id);
     btnValue.innerHTML = "Update";
        valueInput.value = myProduct.label;
       valuePriceInput.value = myProduct.price;
   };
 }

function updateView(updatedLists) {
    listGroupElement.innerHTML = "";
    updatedLists.forEach(viewPrint); }


fetch("https://jsonplaceholder.typicode.com/users")
.then(res=>res.json())
.then(users=>{
    users.forEach(user=>{
        let newLi2Tag=document.createElement("li")
        newLi2Tag.setAttribute("class","list-group")
        newLi2Tag.innerHTML=`<span class="item text">${user.name}</span>`
        let Btn=document.createElement("div")
        let viewInfoBtn=document.createElement("button")
        viewInfoBtn.setAttribute("class","view-info-btn")
        viewInfoBtn.innerText="View Info"
        viewInfoBtn.onclick=function (){
viewUserInfo(user)
        }
        Btn.appendChild(viewInfoBtn)
        newLi2Tag.appendChild(Btn)
        listGroupElement.appendChild(newLi2Tag)

    })
})
.catch(error=>{
    console.log("Your data isn't fetching", error)
})
function viewUserInfo(user){
    alert(`Name: ${user.name}\nUsername: ${user.username}\nEmail: ${user.email}\nPhone: ${user.phone}\nWebsite: ${user.website}`);
}
