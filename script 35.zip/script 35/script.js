
const animalList= document.querySelector('.game-board')
const questionCountElement=document.querySelector('.timer-questionCount')
const scoreElement=document.querySelector('.score')
const gamescoreElement=document.querySelector('.gameScore')
const gameOverElement=document.querySelector('.gameOver ')
const newGameButton=document.querySelector('.newGame')
const timerElement=document.querySelector('.timer')
const rules={
    randomAnswer:null,
    questionCount:3,
    score:0,
    timeLeft:30,
}
let config={
    ...rules
}
scoreElement.innerHTML="Score: "+ config.score
questionCountElement.innerHTML="question Count :"+ config.questionCount
function randomQuestion() {
    let current_animal_Element=document.querySelector('.current-animal')
    let r=Math.floor(Math.random()* animals.length)
    config.randomAnswer=animals[r].name
    current_animal_Element.querySelector('h2').innerHTML=animals[r].name
    current_animal_Element.querySelector('img').src='animal/'+ animals[r].thumbImg
}
randomQuestion()
function makeAnimals() {
    animalList.innerHTML=''
    animals.sort((a,b)=>Math.random() -0.5)
    animals.forEach(animal=>{
        let animalDiv=document.createElement('div')
        animalDiv.classList.add('animal-item')
        let img=document.createElement('img')
        img.src='animal/'+ animal.thumbImg
        img.alt=animal.name
        let name=document.createElement('h3')
        name.textContent=animal.name
        animalDiv.appendChild(img)
        animalDiv.appendChild(name)
        animalList.appendChild(animalDiv)
        animalDiv.onclick=function () {
            console.log()
            if(config.randomAnswer===animalDiv.querySelector('h3').innerText){
                config.score+=10
                scoreElement.innerHTML="Score:"+config.score
            }else{
                config.score-=10
                scoreElement.innerHTML="Score: "+config.score
            }
            config.questionCount--
            questionCountElement.innerHTML="question Count:"+config.questionCount
            if(!config.questionCount){
                gameOverElement.classList.remove('d-none')
                gamescoreElement.innerHTML="Score:"+config.score
                return
            }
            randomQuestion()
        }
    })
}
function startTimer() {
    const timerInterval = setInterval(function () {
        if (config.timeLeft>0) {
            config.timeLeft--;
            timerElement.innerHTML = "Time Left: " + config.timeLeft + "s";
        } else {
            clearInterval(timerInterval);
            gameOverElement.classList.remove('d-none');
            gamescoreElement.innerHTML = "Score: " + config.score;
        }
    }, 1000);}
makeAnimals()
newGameButton.onclick=function (){
    config={
        ...rules
    }
    scoreElement.innerHTML="Score: "+config.score
    questionCountElement.innerHTML="question Count:"+config.questionCount
    makeAnimals()
    randomQuestion()
    startTimer()
    timerElement.innerHTML="Time left:"+config.timeLeft+"s"
    gameOverElement.classList.add('d-none')

}

