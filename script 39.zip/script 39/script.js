const form = document.querySelector('#contactForm');
const submitButton = document.querySelector('#submitButton');

submitButton.addEventListener('click', () => {
    alert('We got your info');

    setTimeout(() => {
        form.reset();
        alert('Form is clear');
    }, 5000);
});