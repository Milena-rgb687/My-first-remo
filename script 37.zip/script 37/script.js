
const config = {
    startValue: 0,
    speed: 1000,
    evenMessage: "Even",
    oddMessage: "Odd",
};


const timer = document.querySelector("#timer");
const startButton = document.querySelector("#start");
const pauseButton = document.querySelector("#pause");
const stopButton = document.querySelector("#stop");
const checkButton = document.querySelector("#check");
const speedControl = document.querySelector("#speed");

let count = config.startValue;
let interval = null;

startButton.addEventListener("click", () => {
    if (interval)
        return;
    interval = setInterval(() => {
        count++;
        timer.textContent = count;
    } );
});

pauseButton.addEventListener("click", () => {
    clearInterval(interval);

});

stopButton.addEventListener("click", () => {
    clearInterval(interval);
    interval = null;
    count = config.startValue;
    timer.textContent = count;
});

checkButton.addEventListener("click", () => {
  if(count%2===0){
      alert(config.evenMessage)
  }else{
      alert(config.oddMessage)
  }
});

speedControl.addEventListener("input", () => {
    if (interval) {
        clearInterval(interval);
        interval = setInterval(() => {
            count++;
            timer.textContent = count

        } );
    }
});