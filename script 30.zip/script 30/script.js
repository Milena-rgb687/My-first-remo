
let publishButton = document.querySelector("#publisbTN");
let outputElement = document.querySelector("#output");

let config = {
    text: null,
    color: null,
    background: null,
    fontsize: null,
    fontFamily: null,
    textAlign: null,
    underline: false,
    italic: false,
    bold: false,
    textShadowX: 0,
    textShadowY: 0,
    textShadowBlur: 0,
    textShadowColor: "#000000",
    textTransform: "none",
};

let storage = localStorage.getItem("style-1");
if (storage) {
    config = JSON.parse(storage);
    applyConfig(config);
}

publishButton.onclick = function () {
    connectInput();
};

function connectInput() {
    let textInput = document.querySelector("#textInput");
    let fontSizeInput = document.querySelector("#fontSize");
    let fontFamilySelect = document.querySelector("#fontFamily");
    let textColorInput = document.querySelector("#textColor");
    let backgroundColorInput = document.querySelector("#backgroundColor");
    let textAlignSelect = document.querySelector("#text-align"); // Ուղղված ID
    let textShadowXInput = document.querySelector("#shadowX");
    let textShadowYInput = document.querySelector("#shadowY");
    let textShadowBlurInput = document.querySelector("#blur");
    let textShadowColorInput = document.querySelector("#shadowColor");
    let underlineCheckbox = document.querySelector("#underline");
    let italicCheckbox = document.querySelector("#italic");
    let boldCheckbox = document.querySelector("#bold");
    let transformRadios = document.querySelectorAll(".transformAll");

    let selectedTransform = "none";
    for (let i = 0; i < transformRadios.length; i++) {
        if (transformRadios[i].checked) {
            selectedTransform = transformRadios[i].value;
            break;
        }
    }
    let letterSpacingInput=document.querySelector("#letter-spacing");
    let lineHeightSpacingInput=document.querySelector("#line-height");
    let wordSpacingInput=document.querySelector("#word-spacing");

    config = {
        text: textInput.value || "No text provided!",
        color: textColorInput.value || "#000000",
        background: backgroundColorInput.value || "#ffffff",
        fontsize: (fontSizeInput.value || "16") + "px",
        fontFamily: fontFamilySelect.value || "sans-serif",
        textAlign: textAlignSelect.value || "left",
        underline: underlineCheckbox.checked,
        italic: italicCheckbox.checked,
        bold: boldCheckbox.checked,
        textTransform: selectedTransform,
        textShadowX: textShadowXInput.value || 0,
        textShadowY: textShadowYInput.value || 0,
        textShadowBlur: textShadowBlurInput.value || 0,
        textShadowColor: textShadowColorInput.value || "#000000",
        letterSpacing:letterSpacingInput.value+"px",
        lineHeight:lineHeightSpacingInput.value,
        wordSpacing:wordSpacingInput.value+"px",
    };

    localStorage.setItem("style-1", JSON.stringify(config));
    applyConfig(config);
}

function applyConfig(config) {
    outputElement.textContent = config.text;
    outputElement.style.color = config.color;
    outputElement.style.backgroundColor = config.background;
    outputElement.style.fontSize = config.fontsize;
    outputElement.style.fontFamily = config.fontFamily;
    outputElement.style.textAlign = config.textAlign;
    outputElement.style.textDecoration = config.underline ? "underline" : "none";
    outputElement.style.fontStyle = config.italic ? "italic" : "normal";
    outputElement.style.fontWeight = config.bold ? "bold" : "normal";
    outputElement.style.textTransform = config.textTransform;
    outputElement.style.letterSpacing=config.letterSpacing;
    outputElement.style.wordSpacing=config.wordSpacing;
    outputElement.style.lineHeight=config.lineHeight;
    outputElement.style.textShadow = `${config.textShadowX}px ${config.textShadowY}px ${config.textShadowBlur}px ${config.textShadowColor}`;
}