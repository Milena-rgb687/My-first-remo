
const users = [];

document.querySelector('#registerForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const name = document.querySelector('#register-name').value.trim();
    const email = document.querySelector('#register-email').value.trim();
    const password = document.querySelector('#register-password').value.trim();
    const confirmPassword = document.querySelector('#register-confirm-password').value.trim();

    const nameError = document.querySelector('#registerNameError');
    const emailError = document.querySelector('#registerEmailError');
    const passwordError = document.querySelector('#registerPasswordError');
    const confirmPasswordError = document.querySelector('#registerConfirmPasswordError');

    nameError.textContent = '';
    emailError.textContent = '';
    passwordError.textContent = '';
    confirmPasswordError.textContent = '';

    let isValid = true;

    if (!name || /\d/.test(name)) {
        nameError.textContent = 'Name cannot be empty or contain numbers.';
        isValid = false;
    }

    if (!email || !/^[\w-]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
        emailError.textContent = 'Please enter a valid email address.';
        isValid = false;
    }

    if (!password || password.length < 6) {
        passwordError.textContent = 'Password must be at least 6 characters long.';
        isValid = false;
    }

    if (password !== confirmPassword) {
        confirmPasswordError.textContent = 'Passwords do not match.';
        isValid = false;
    }

    if (users.some(user => user.email === email)) {
        emailError.textContent = 'This email is already registered.';
        isValid = false;
    }

    if (isValid) {
        users.push({ name, email, password });
        alert('Registration successful!');
        document.querySelector('#registerForm')
        updateUserList();
    }
});

document.querySelector('#loginForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const email = document.querySelector('#login-email').value.trim();
    const password = document.querySelector('#login-password').value.trim();

    const emailError = document.querySelector('#loginEmailError');
    const passwordError = document.querySelector('#loginPasswordError');

    emailError.textContent = '';
    passwordError.textContent = '';

    const user = users.find(user => user.email === email);

    if (!user) {
        emailError.textContent = 'Email not found. Please register.';
    } else if (user.password !== password) {
        passwordError.textContent = 'Incorrect password.';
    } else {
        alert(`Welcome, ${user.name}!`);
        document.querySelector('#loginForm')
    }
});

    function updateUserList() {
        const userList = document.querySelector('#userList');
        userList.innerHTML = '';
        users.forEach(user => {
            userList.innerHTML += `<li>${user.name}</li>`
        });
    }
updateUserList()