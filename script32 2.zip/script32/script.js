document.querySelector("#registrationForm").onsubmit = (e) => {
    e.preventDefault();
};

function goToNext(part) {
    const form = document.querySelector("#registrationForm");
    const fields = form.elements;

    if (part === 1) {
        const name = fields.name.value.trim();
        const surname = fields.surname.value.trim();
        const fathername = fields.fathername.value.trim();
        const phone = fields.phone.value.trim();

        if (name.length > 2 && surname.length > 2 && fathername.length > 2 && phone.length > 5) {
            document.querySelector("#part1").style.display = "none";
            document.querySelector("#part2").style.display = "block";
        } else {
            alert("Please enter correct information");
        }
    } else if (part === 2) {
        const email = fields.email.value.trim();
        const password = fields.password.value.trim();

        if (email.length > 5 && password.length > 5) {
            document.querySelector("#part2").style.display = "none";
            document.querySelector("#part3").style.display = "block";
        } else {
            alert("Please enter correct information");
        }
    }
}